// Testy bez připojení: text komponenty, čísla, parser orderů, stránka GUI, statistiky, GitHub API (falešné).
'use strict';
const assert = require('assert');
const http = require('http');
const util = require('../lib/util');
const gui = require('../lib/gui');
const pub = require('../lib/publish');
const { deepMerge } = require('../bot');

const registry = require('prismarine-registry')('1.21.4');
const Item = require('prismarine-item')(registry);
util.initChat(registry);

let passed = 0;
function t(name, fn) {
  try { fn(); passed++; console.log('  OK  ' + name); }
  catch (e) { console.error('  FAIL ' + name + ' → ' + e.message); process.exitCode = 1; }
}
const cfg = require('../config');

// --- NBT komponenty jako z 1.21.4 protokolu ---
const str = (s) => ({ type: 'string', value: s });
const byte = (n) => ({ type: 'byte', value: n });
const comp = (o) => ({ type: 'compound', value: o });
const list = (a) => ({ type: 'list', value: { type: 'compound', value: a } });
const part = (text, color, extra = {}) => ({ text: str(text), color: str(color), ...extra });
function makeItem(name, count, customName, loreLines) {
  const it = new Item(registry.itemsByName[name].id, count, null);
  it.components = []; it.componentMap = new Map();
  if (customName) it.componentMap.set('custom_name', { type: 'custom_name', data: comp({ text: str(''), italic: byte(0), extra: list([part(customName, 'white')]) }) });
  if (loreLines) it.componentMap.set('lore', { type: 'lore', data: loreLines.map((l) => (l == null ? str('') : comp({ text: str(''), italic: byte(0), extra: list(l) }))) });
  return it;
}
const orderItem = (price, delivered, total) => makeItem('spruce_log', 1, 'Spruce Logs', [
  null, [part('$ ', 'green', { bold: byte(1) }), part(String(price), 'white', { bold: byte(1) }), part(' each', 'gray')], [part(`${delivered}/${total} Delivered`, 'gray')], null, [part('Click to deliver items', 'gray')],
]);
function fakeWindow(title, items) {
  const slots = new Array(90).fill(null);
  items.forEach((it, i) => { if (it) slots[i] = it; });
  return { id: 3, title: str(title), slots, inventoryStart: 54, inventoryEnd: 90, type: 'minecraft:generic_9x6' };
}

console.log('— util —');
t('parseMoney', () => { assert.strictEqual(util.parseMoney('491k'), 491000); assert.strictEqual(util.parseMoney('1.2M'), 1200000); assert.strictEqual(util.parseMoney('63.4'), 63.4); assert.strictEqual(util.parseMoney('1,234'), 1234); assert.ok(Number.isNaN(util.parseMoney('abc'))); });
t('toPlain NBT / JSON / §', () => { assert.strictEqual(util.toPlain(str('Orders (Page 1)')), 'Orders (Page 1)'); assert.strictEqual(util.toPlain('{"text":"§aOrders §7(Page 2)"}'), 'Orders (Page 2)'); assert.strictEqual(util.toPlain(comp({ translate: str('block.minecraft.spruce_log') })), 'Spruce Log'); });
t('isPriceSane', () => { assert.ok(util.isPriceSane(65, [60, 62, 63])); assert.ok(!util.isPriceSane(800, [60, 62, 63])); assert.ok(util.isPriceSane(800, [])); });
t('deepMerge nepřepíše sourozence', () => { const m = deepMerge({ a: { x: 1, y: 2 }, b: 1 }, { a: { y: 3 } }); assert.deepStrictEqual(m, { a: { x: 1, y: 3 }, b: 1 }); });

console.log('— gui parser —');
t('parseOrder ze screenshotu', () => { const o = gui.parseOrder({ name: 'Spruce Logs', lore: ['', '$ 63.4 each', '491k/750k Delivered', '', 'Click to deliver items'] }, cfg); assert.deepStrictEqual([o.price, o.delivered, o.total, o.remaining], [63.4, 491000, 750000, 259000]); });
t('parseOrder bez ceny → null', () => assert.strictEqual(gui.parseOrder({ name: 'Filter', lore: ['Click to filter'] }, cfg), null));
t('itemTexts čte custom name a lore', () => { const x = gui.itemTexts(orderItem(63.4, '491k', '750k')); assert.strictEqual(x.name, 'Spruce Logs'); assert.strictEqual(x.lore[1], '$ 63.4 each'); });

const items = [];
[63.4, 63.4, 63.2, 63, 62.5].forEach((p, i) => { items[i] = orderItem(p, i % 2 ? '10k' : '491k', '750k'); });
items[5] = orderItem(58, '750k', '750k');                       // plně doručený
items[6] = makeItem('stripped_spruce_log', 1, 'Stripped Spruce Logs', [[part('$ 99 each', 'green')], [part('0/1k Delivered', 'gray')]]);   // jiný item
items[47] = makeItem('hopper', 1, 'Filter', [[part('Click', 'gray')]]);
items[53] = makeItem('arrow', 1, 'Next Page', null);
const w = cfg.watch[0];
const page = gui.readPage(fakeWindow('Orders (Page 1)', items), w, cfg, 1);
t('readPage: 6 spruce orderů, stripped vynechán, šipka slot 53', () => { assert.strictEqual(page.orders.length, 6); assert.strictEqual(page.nextSlot, 53); assert.strictEqual(page.title, 'Orders (Page 1)'); assert.ok(page.orders.every((o) => o.name === 'Spruce Logs')); });
const items2 = items.slice(); items2[53] = makeItem('arrow', 1, null, null); items2[45] = makeItem('arrow', 1, null, null);
t('bezejmenné šipky podle pozice', () => { const p2 = gui.readPage(fakeWindow('Orders (Page 2)', items2), w, cfg, 2); assert.strictEqual(p2.nextSlot, 53); });
t('otisk okna ignoruje kliknutý slot', () => { const a = gui.windowFingerprint(fakeWindow('X', items), 53); const b = gui.windowFingerprint(fakeWindow('X', items.map((it, i) => (i === 53 ? null : it))), 53); assert.strictEqual(a, b); });
t('dumpText obsahuje lore', () => assert.ok(gui.dumpText(fakeWindow('Orders (Page 1)', items)).includes('$ 63.4 each')));

console.log('— publish —');
const st = pub.buildStats(page.orders, w, 5);
t('stats: plně doručený ven, best, poptávka', () => { assert.strictEqual(st.count, 5); assert.strictEqual(st.best, 63.4); assert.strictEqual(st.demand, 259000 * 3 + 740000 * 2); });
t('effectiveTop přeskočí výkřik', () => assert.strictEqual(pub.effectiveTop([{ price: 800, remaining: 100 }, { price: 63, remaining: 300000 }], 25000), 63));
t('reálné ordery: $1 ordery ven z poptávky i váženého průměru', () => {
  const book = [
    { price: 67, remaining: 450 }, { price: 63.66, remaining: 1798000 }, { price: 63, remaining: 37100000 },
    { price: 40, remaining: 100000 }, { price: 1, remaining: 700000000 }, { price: 1, remaining: 4579000 },
  ];
  const r = pub.buildStats(book, { minRealDemand: 25000, realPriceFactor: 0.5 }, 5);
  assert.strictEqual(r.effective_top, 63.66);
  assert.strictEqual(r.count_real, 4);                       // 67, 63.66, 63, 40 (≥ 31.83)
  assert.strictEqual(r.demand_real, 450 + 1798000 + 37100000 + 100000);
  assert.ok(r.weighted_avg_real > 62 && r.weighted_avg_real < 63.1, 'vážený průměr reálných ~63');
  assert.ok(r.weighted_avg < 5, 'celkový vážený průměr zkažený $1 ordery');
  assert.strictEqual(r.median_real, 63.33);
});
t('historie nese reálný vrchol (eff) i reálnou poptávku', () => {
  const s1 = pub.buildSnapshot(null, [{ price: 67, remaining: 450 }, { price: 63, remaining: 3000000 }, { price: 1, remaining: 9e8 }], { w: { key: 'x', match: 'X', minRealDemand: 25000 }, pages: 1 });
  assert.strictEqual(s1.history[0].eff, 63); assert.strictEqual(s1.history[0].dreal, 3000450); assert.strictEqual(s1.hourly[0].eff_avg, 63);
  assert.strictEqual(s1.effective_top, 63); assert.strictEqual(s1.best, 67); assert.strictEqual(s1.truncated, false);
});
const s1 = pub.buildSnapshot(null, page.orders, { w, pages: 1 });
const s2 = pub.buildSnapshot(s1, page.orders, { w, pages: 1 });
t('snapshot + historie', () => { assert.strictEqual(s1.status, 'ok'); assert.strictEqual(s2.history.length, 2); assert.strictEqual(s2.hourly[0].samples, 2); assert.strictEqual(s2.bot.runs, 2); });
t('heartbeat zachová ceny', () => { const hb = pub.heartbeatSnapshot(s2, { w, status: 'sleeping', note: 'spí' }); assert.strictEqual(hb.best, 63.4); assert.strictEqual(hb.status, 'sleeping'); });
t('ořez historie 48 h', () => assert.strictEqual(pub.updateHistory({ history: [{ t: Math.floor(Date.now() / 1000) - 3 * 86400, best: 1 }], hourly: [] }, Date.now(), st).history.length, 1));

console.log('— trade —');
const trade = require('../lib/trade');
const T = { buyBelow: 60, sellAbove: 65, buyUnits: 2880, maxOrders: 1, bidAboveTop: 1, priceDecimals: 1, neverSellAtLoss: true, minProfitPct: 0, cancelAfterMinutes: 30, minBalanceReserve: 0, maxSpendPerHour: 0 };
const BOOK = [{ price: 70, remaining: 100 }, { price: 66, remaining: 5000 }, { price: 64, remaining: 400000 }, { price: 1, remaining: 9e8 }];
t('normalizeUnits: celé stránky, min 2880', () => { assert.strictEqual(trade.normalizeUnits(5000), 2880); assert.strictEqual(trade.normalizeUnits(5760), 5760); assert.strictEqual(trade.normalizeUnits(0), 2880); assert.strictEqual(trade.normalizeUnits('8640'), 8640); });
t('realizedSellPrice váží objemem (výkřik $70 na 100 ks nezkreslí)', () => {
  const r = trade.realizedSellPrice([{ price: 70, remaining: 100 }, { price: 66, remaining: 500 }, { price: 64, remaining: 400000 }], 2880);
  assert.ok(Math.abs(r - (100 * 70 + 500 * 66 + 2280 * 64) / 2880) < 1e-9, 'r=' + r);
  assert.ok(Number.isNaN(trade.realizedSellPrice([], 10)));
  assert.strictEqual(trade.realizedSellPrice([{ price: 60, remaining: 10 }], 2880), 60, 'tenká kniha → cena posledního orderu');
});
t('decide: levno → nákup o $1 nad reálným vrcholem', () => {
  const d = trade.decide({ t: T, myOrders: [], book: BOOK, effTop: 57.5, balance: 1e6, now: 0, lastBuyAt: 0, spentLastHour: 0 });
  assert.ok(d.buy, 'má koupit'); assert.strictEqual(d.buy.price, 58.5); assert.strictEqual(d.buy.amount, 2880); assert.strictEqual(d.buy.cost, 2880 * 58.5);
});
t('decide: cena orderu nikdy nad buyBelow (strop)', () => { const d = trade.decide({ t: T, myOrders: [], book: BOOK, effTop: 59.5, balance: 1e6, now: 0 }); assert.strictEqual(d.buy.price, 60); });
t('decide: není levno → nekupovat', () => { const d = trade.decide({ t: T, myOrders: [], book: BOOK, effTop: 60, balance: 1e6, now: 0 }); assert.strictEqual(d.buy, null); assert.ok(d.skipped.some((s) => /není levno/.test(s))); });
t('decide: plný počet orderů → nekupovat', () => { const d = trade.decide({ t: T, myOrders: [{ slot: 0, price: 58, delivered: 100, total: 2880, completed: false }], book: BOOK, effTop: 55, balance: 1e6, now: 0 }); assert.strictEqual(d.buy, null); assert.ok(d.skipped.some((s) => /plný počet/.test(s))); });
t('decide: rezerva bez známého zůstatku → nekupovat, bez rezervy → koupit', () => {
  const a = trade.decide({ t: { ...T, minBalanceReserve: 1000 }, myOrders: [], book: BOOK, effTop: 55, balance: NaN, now: 0 }); assert.strictEqual(a.buy, null);
  const b = trade.decide({ t: T, myOrders: [], book: BOOK, effTop: 55, balance: NaN, now: 0 }); assert.ok(b.buy);
  const c = trade.decide({ t: { ...T, minBalanceReserve: 100000 }, myOrders: [], book: BOOK, effTop: 55, balance: 150000, now: 0 }); assert.strictEqual(c.buy, null, 'nezbývá rozpočet');
});
t('decide: hodinový limit útraty a cooldown', () => {
  const a = trade.decide({ t: { ...T, maxSpendPerHour: 100000 }, myOrders: [], book: BOOK, effTop: 55, balance: 1e6, now: 0, spentLastHour: 90000 }); assert.strictEqual(a.buy, null);
  const b = trade.decide({ t: { ...T, cooldownMinutes: 10 }, myOrders: [], book: BOOK, effTop: 55, balance: 1e6, now: 5 * 60000, lastBuyAt: 1 }); assert.strictEqual(b.buy, null); assert.ok(b.skipped.some((s) => /čekám/.test(s)));
});
t('decide: naplněný order se prodá až nad sellAbove', () => {
  const my = [{ slot: 10, price: 58, delivered: 2880, total: 2880, completed: true }];
  const low = trade.decide({ t: T, myOrders: my, book: [{ price: 63, remaining: 1e6 }], effTop: 63, now: 0 }); assert.strictEqual(low.sells.length, 0); assert.ok(low.skipped.some((s) => /držím naplněný/.test(s)));
  const ok = trade.decide({ t: T, myOrders: my, book: [{ price: 66, remaining: 1e6 }], effTop: 66, now: 0 }); assert.strictEqual(ok.sells.length, 1); assert.strictEqual(ok.sells[0].slot, 10); assert.ok(ok.sells[0].profit > 0);
});
t('decide: nikdy neprodat pod nákupní cenu (neverSellAtLoss)', () => {
  const my = [{ slot: 10, price: 70, delivered: 2880, total: 2880, completed: true }];
  const a = trade.decide({ t: T, myOrders: my, book: [{ price: 66, remaining: 1e6 }], effTop: 66, now: 0 }); assert.strictEqual(a.sells.length, 0);
  const b = trade.decide({ t: { ...T, neverSellAtLoss: false }, myOrders: my, book: [{ price: 66, remaining: 1e6 }], effTop: 66, now: 0 }); assert.strictEqual(b.sells.length, 1);
});
t('decide: zrušený order s aspoň stránkou dodaných kusů se prodá', () => {
  const my = [{ slot: 3, price: 58, delivered: 2880, total: 5760, completed: false, canceled: true }];
  const d = trade.decide({ t: T, myOrders: my, book: [{ price: 66, remaining: 1e6 }], effTop: 66, now: 0 }); assert.strictEqual(d.sells.length, 1); assert.strictEqual(d.sells[0].qty, 2880);
});
t('decide: buyBelow 0 = nenakupovat, sellAbove 0 = neprodávat', () => {
  const d = trade.decide({ t: { ...T, buyBelow: 0, sellAbove: 0 }, myOrders: [{ slot: 1, price: 50, delivered: 2880, total: 2880, completed: true }], book: BOOK, effTop: 40, balance: 1e6, now: 0 });
  assert.strictEqual(d.buy, null); assert.strictEqual(d.sells.length, 0);
});
t('findStuck: ruší jen order bez pohybu po limitu', () => {
  const o = [{ slot: 1, price: 58, delivered: 0, total: 2880, completed: false }];
  const a = trade.findStuck(o, {}, 30 * 60000, 1000); assert.strictEqual(a.toCancel, null); assert.ok(a.firstSeen['58|2880']);
  const b = trade.findStuck(o, a.firstSeen, 30 * 60000, 1000 + 31 * 60000); assert.ok(b.toCancel); assert.strictEqual(b.toCancel.o.slot, 1);
  const moved = [{ slot: 1, price: 58, delivered: 500, total: 2880, completed: false }];
  const c = trade.findStuck(moved, a.firstSeen, 30 * 60000, 1000 + 31 * 60000); assert.strictEqual(c.toCancel, null, 'order se hýbe');
  const d = trade.findStuck(moved, c.firstSeen, 30 * 60000, 1000 + 70 * 60000); assert.strictEqual(d.toCancel, null, 'částečně dodaný (< stránka) se neruší');
  const e = trade.findStuck(o, a.firstSeen, 0, 1000 + 999 * 60000); assert.strictEqual(e.toCancel, null, 'cancelAfter 0 = nikdy');
});
t('findInWindow: přesná shoda před částečnou', () => {
  const win = fakeWindow('Select Item', [makeItem('stripped_spruce_log', 1, 'Stripped Spruce Log', null), makeItem('spruce_log', 1, 'Spruce Log', null), makeItem('chest', 1, 'Your Orders', null)]);
  assert.strictEqual(trade.findInWindow(win, 'Spruce Log').slot, 1);
  assert.strictEqual(trade.findInWindow(win, null, 'chest').slot, 2);
  assert.strictEqual(trade.findInWindow(win, 'Your Orders', 'chest').slot, 2);
  assert.strictEqual(trade.findInWindow(win, 'Nope'), null);
});
t('fillCtx + formatPrice', () => { assert.strictEqual(trade.fillCtx('{item}|{amount}|{price}', { item: 'spruce log', amount: 2880, price: '58.5' }), 'spruce log|2880|58.5'); assert.strictEqual(trade.formatPrice(58.5, 1), '58.5'); assert.strictEqual(trade.formatPrice(58.55, 0), '59'); assert.strictEqual(trade.formatPrice(60, 1), '60'); });

(async () => {
  const files = new Map(); let puts = 0;
  const server = http.createServer((req, res) => {
    let body = ''; req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const p = req.url.match(/contents\/(.+?)(\?.*)?$/)[1];
      if (req.method === 'GET') { if (!files.has(p)) { res.writeHead(404); return res.end('{"message":"Not Found"}'); } const f = files.get(p); res.writeHead(200); return res.end(JSON.stringify({ sha: f.sha, content: Buffer.from(f.content).toString('base64') })); }
      const j = JSON.parse(body); const ex = files.get(p);
      if (ex && j.sha !== ex.sha) { res.writeHead(409); return res.end('{"message":"sha mismatch"}'); }
      const sha = 'sha' + (++puts); files.set(p, { sha, content: Buffer.from(j.content, 'base64').toString('utf8') });
      res.writeHead(ex ? 200 : 201); res.end(JSON.stringify({ content: { sha } }));
    });
  });
  await new Promise((r) => server.listen(0, r));
  const store = new pub.GitHubStore({ owner: 'marek', repo: 'spruce-data', token: 'T', apiBase: `http://127.0.0.1:${server.address().port}` });
  try {
    assert.strictEqual(await store.getFile('prices.json'), null);
    await store.putFile('prices.json', '{"a":1}', 'first');
    await store.putFile('prices.json', '{"a":2}', 'second');
    files.set('prices.json', { sha: 'ext', content: '{"a":3}' });
    await store.putFile('prices.json', '{"a":4}', 'third');
    assert.strictEqual((await store.getFile('prices.json')).content, '{"a":4}');
    passed++; console.log('  OK  GitHub API: vytvoření, přepis, oprava sha po konfliktu');
  } catch (e) { console.error('  FAIL GitHub API → ' + e.message); process.exitCode = 1; }
  server.close();
  console.log(`\nHotovo: ${passed} testů prošlo.`);
})();
