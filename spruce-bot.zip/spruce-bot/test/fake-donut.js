'use strict'
/*
 * Falešný "DonutSMP" pro testy bez skutečného serveru a účtu.
 *  - Minecraft server (protokol 1.21.4, offline mód) na portu 25599
 *  - "/orders spruce log" otevře knihu "Orders (Page 1)" se spruce logy a šipkou
 *    na další stránku; má 3 stránky, poslední bez šipky
 *  - "/orders" otevře hlavní menu s chestkou "Your Orders" → New Order (Item →
 *    Search → cedule → výběr itemu → Amount → cedule → Price → cedule → Confirm),
 *    naplněný order → Collect → emerald Sell → zelené sklo; Cancel → potvrzení
 *  - "/bal" odpoví zůstatkem v chatu
 *  - falešné GitHub API na portu 8787 (ukládá do paměti)
 *
 * Spuštění samostatně:  node test/fake-donut.js
 *  FAKE_INPLACE=1  další stránka přepíše obsah stejného okna místo nového okna
 *  FAKE_FILL_MS=3000  za kolik ms se nový order "naplní" (0 = nikdy)
 * Používá ho  node test/e2e.js  a  node test/trade.e2e.js
 */
const http = require('http')
const mc = require('minecraft-protocol')
const registry = require('prismarine-registry')('1.21.4')
const Item = require('prismarine-item')(registry)

const VERSION = '1.21.4'
const MC_PORT = parseInt(process.env.FAKE_MC_PORT || '25599', 10)
const GH_PORT = parseInt(process.env.FAKE_GH_PORT || '8787', 10)
const INPLACE = process.env.FAKE_INPLACE === '1'
const FILL_MS = process.env.FAKE_FILL_MS !== undefined ? parseInt(process.env.FAKE_FILL_MS, 10) : 3000

const str = (s) => ({ type: 'string', value: s })
const byte = (n) => ({ type: 'byte', value: n })
const comp = (obj) => ({ type: 'compound', value: obj })
const list = (arr) => ({ type: 'list', value: { type: 'compound', value: arr } })
const part = (text, color, extra = {}) => ({ text: str(text), color: str(color), ...extra })

function makeItem (name, count, customName, loreLines) {
  const it = new Item(registry.itemsByName[name].id, count, null)
  it.components = []
  it.componentMap = new Map()
  if (customName) {
    const c = { type: 'custom_name', data: comp({ text: str(''), italic: byte(0), extra: list([part(customName, 'white')]) }) }
    it.components.push(c); it.componentMap.set(c.type, c)
  }
  if (loreLines) {
    const c = {
      type: 'lore',
      data: loreLines.map(line => line == null ? str('') : comp({ text: str(''), italic: byte(0), extra: list(typeof line === 'string' ? [part(line, 'gray')] : line) }))
    }
    it.components.push(c); it.componentMap.set(c.type, c)
  }
  return it
}

function fmtK (n) {
  if (n >= 1e6) return (Math.round(n / 1e4) / 100) + 'm'
  if (n >= 1e3) return (Math.round(n / 10) / 100) + 'k'
  return String(n)
}

function orderItem (price, delivered, total, extraLore) {
  return makeItem('spruce_log', 1, 'Spruce Logs', [
    null,
    [part('$ ', 'green', { bold: byte(1) }), part(String(price), 'white', { bold: byte(1) }), part(' each', 'gray')],
    [part(`${delivered}/${total} Delivered`, 'gray')],
    null,
    ...(extraLore || ['Click to deliver items'])
  ])
}

function bottomBar (items) {
  items[47] = makeItem('hopper', 1, 'Filter', ['Click to change', '', '▪ Most Per Item', '▪ Most Paid', '▪ Recently Listed'])
  items[48] = makeItem('amethyst_shard', 1, 'Shard Shop', ['Click to view'])
  items[49] = makeItem('book', 1, 'Orders', ['Request and deliver items'])
  items[50] = makeItem('oak_sign', 1, 'Search', ['Click to search'])
  items[51] = makeItem('chest', 1, 'Your Orders', ['Click to view'])
}

// 3 stránky orderů, ceny klesají
function buildPage (pageNo, totalPages) {
  const items = new Array(54).fill(null)
  const base = 70 - (pageNo - 1) * 5
  for (let i = 0; i < 45; i++) {
    if (pageNo === totalPages && i > 12) break // poslední stránka není plná
    const price = Math.round((base - i * 0.1) * 10) / 10
    const total = ['750k', '1M', '250k', '2.5M'][i % 4]
    const delivered = ['491k', '0', '120k', '2.4M'][i % 4]
    items[i] = orderItem(price, delivered, total)
  }
  bottomBar(items)
  if (pageNo > 1) items[45] = makeItem('arrow', 1, 'Previous Page', null)
  if (pageNo < totalPages) items[53] = makeItem('arrow', 1, 'Next page', ['Click to view next page'])
  return items
}

function slotsToNotch (items) {
  const out = []
  for (let i = 0; i < 54 + 36; i++) out.push(Item.toNotch(items[i] || null))
  return out
}

const server = mc.createServer({ 'online-mode': false, version: VERSION, port: MC_PORT, motd: 'fake donut' })
server.on('listening', () => console.log(`[fake-mc] poslouchám na 127.0.0.1:${MC_PORT} (${VERSION})`))

// stav trhu (sdílený mezi připojeními, aby přežil reconnect bota)
const market = { balance: 12345678, myOrders: [], created: [], sold: [], canceled: [], nextId: 1 }
module.exports = { MC_PORT, GH_PORT, market }

server.on('playerJoin', (client) => {
  console.log('[fake-mc] připojil se', client.username)
  const login = { ...registry.loginPacket, entityId: 1 }
  client.write('login', login)
  client.write('position', {
    x: 0, y: 80, z: 0, yaw: 0, pitch: 0, dx: 0, dy: 0, dz: 0,
    flags: { x: false, y: false, z: false, yaw: false, pitch: false, dx: false, dy: false, dz: false, yawDelta: false },
    teleportId: 1
  })
  client.write('update_health', { health: 20, food: 20, foodSaturation: 5 }) // mineflayer emituje 'spawn' až po tomto

  let windowId = 0
  let page = 0
  let cur = null           // { name, items, on: {slot: fn} }
  const TOTAL_PAGES = 3
  const draft = { item: null, amount: null, price: null }
  let pendingInput = null  // 'search' | 'amount' | 'price'
  let selectedOrder = null

  function chat (text) {
    try { client.write('system_chat', { content: str(text), isActionBar: false }) } catch (e) { console.log('[fake-mc] system_chat chyba:', e.message) }
  }

  function show (win) {
    cur = win
    windowId = (windowId % 100) + 1
    const title = comp({ text: str(win.title), color: str('dark_gray') })
    client.write('open_window', { windowId, inventoryType: 5, windowTitle: title })
    client.write('window_items', { windowId, stateId: 1, items: slotsToNotch(win.items), carriedItem: Item.toNotch(null) })
    console.log(`[fake-mc] otevřeno okno ${windowId}: ${win.title}`)
  }

  function closeWin () {
    if (windowId) { try { client.write('close_window', { windowId }) } catch (_) {} }
    windowId = 0; cur = null
  }

  function openSign (what) {
    pendingInput = what
    closeWin()
    setTimeout(() => client.write('open_sign_entity', { location: { x: 10, y: 70, z: 10 }, isFrontText: true }), 80)
    console.log(`[fake-mc] otevřena cedule pro: ${what}`)
  }

  // ---- kniha orderů ----
  function openPage (no) {
    page = no
    if (INPLACE && windowId > 0 && cur && cur.name === 'book') {
      cur.items = buildPage(no, TOTAL_PAGES)
      client.write('window_items', { windowId, stateId: no, items: slotsToNotch(cur.items), carriedItem: Item.toNotch(null) })
      console.log(`[fake-mc] okno ${windowId} přepsáno na stránku ${no} (in-place)`)
      return
    }
    show({
      name: 'book',
      title: INPLACE ? 'Orders' : `Orders (Page ${no})`,
      items: buildPage(no, TOTAL_PAGES),
      on: {
        53: () => { if (page < TOTAL_PAGES) setTimeout(() => openPage(page + 1), 120) },
        45: () => { if (page > 1) setTimeout(() => openPage(page - 1), 120) },
        51: () => setTimeout(openMyOrders, 120)
      }
    })
  }

  // ---- hlavní menu ----
  function openMain () {
    const items = new Array(54).fill(null)
    for (let i = 0; i < 9; i++) items[i] = orderItem(70 - i, '0', '10k')
    bottomBar(items)
    show({ name: 'main', title: 'Orders', items, on: { 51: () => setTimeout(openMyOrders, 120) } })
  }

  // ---- moje ordery ----
  function myOrderItem (o) {
    const extra = o.completed ? [[part('Order Completed', 'green')], 'Click to collect'] : o.canceled ? [[part('Order Canceled', 'red')], 'Click to collect'] : ['Click to view']
    return orderItem(o.price, fmtK(o.delivered), fmtK(o.total), extra)
  }
  function openMyOrders () {
    const items = new Array(54).fill(null)
    const on = {}
    market.myOrders.forEach((o, i) => {
      items[i] = myOrderItem(o)
      on[i] = () => { selectedOrder = o; setTimeout(openOrderView, 120) }
    })
    items[49] = makeItem('gray_stained_glass_pane', 1, 'New Order', ['Click to create a new order'])
    on[49] = () => { draft.item = null; draft.amount = null; draft.price = null; setTimeout(openNewOrder, 120) }
    items[53] = makeItem('barrier', 1, 'Back', null)
    on[53] = () => setTimeout(openMain, 120)
    show({ name: 'mine', title: 'Your Orders', items, on })
  }

  // ---- nový order ----
  function openNewOrder () {
    const items = new Array(27).fill(null)
    items[11] = makeItem('paper', 1, 'Item', [draft.item ? `Selected: ${draft.item}` : 'Click to select'])
    items[13] = makeItem('paper', 1, 'Amount', [draft.amount ? `Amount: ${draft.amount}` : 'Click to set'])
    items[15] = makeItem('gold_nugget', 1, 'Price', [draft.price ? `Price: $${draft.price} each` : 'Click to set'])
    items[22] = makeItem('lime_stained_glass_pane', 1, 'Confirm', ['Click to create order'])
    items[18] = makeItem('barrier', 1, 'Cancel', null)
    show({
      name: 'neworder',
      title: 'New Order',
      items,
      on: {
        11: () => setTimeout(openSelectItem, 120),
        13: () => openSign('amount'),
        15: () => openSign('price'),
        22: () => {
          const amount = parseInt(draft.amount, 10); const price = parseFloat(draft.price)
          if (!draft.item || !amount || !price) { chat('Fill in item, amount and price first!'); return }
          const cost = amount * price
          if (cost > market.balance) { chat('You do not have enough money!'); closeWin(); return }
          market.balance -= cost
          const o = { id: market.nextId++, item: draft.item, price, total: amount, delivered: 0, completed: false, canceled: false, createdAt: Date.now() }
          market.myOrders.push(o); market.created.push({ ...o })
          console.log(`[fake-mc] ORDER VYTVOŘEN: ${amount}× ${draft.item} po $${price} (zůstatek $${market.balance})`)
          chat(`Order created: ${amount}x ${draft.item} for $${price} each.`)
          if (FILL_MS > 0) setTimeout(() => { if (!o.canceled) { o.delivered = o.total; o.completed = true; console.log(`[fake-mc] order ${o.id} naplněn`) } }, FILL_MS)
          closeWin()
        },
        18: () => closeWin()
      }
    })
  }

  function openSelectItem (query) {
    const items = new Array(54).fill(null)
    const on = {}
    const all = [['spruce_log', 'Spruce Log'], ['stripped_spruce_log', 'Stripped Spruce Log'], ['spruce_planks', 'Spruce Planks'], ['oak_log', 'Oak Log'], ['diamond', 'Diamond']]
    const q = (query || '').toLowerCase()
    const found = q ? all.filter(([, n]) => n.toLowerCase().includes(q)) : all
    // Stripped první – bot musí vybrat přesnou shodu, ne první částečnou
    found.sort((a, b) => (a[0] === 'stripped_spruce_log' ? -1 : b[0] === 'stripped_spruce_log' ? 1 : 0))
    found.forEach(([id, name], i) => {
      items[i] = makeItem(id, 1, null, ['Click to select'])
      on[i] = () => { draft.item = name; setTimeout(openNewOrder, 120) }
    })
    items[49] = makeItem('oak_sign', 1, 'Search', ['Click to search'])
    on[49] = () => openSign('search')
    show({ name: 'select', title: 'Select Item', items, on })
  }

  // ---- detail orderu / collect / sell / cancel ----
  function openOrderView () {
    const o = selectedOrder
    const items = new Array(27).fill(null)
    items[13] = myOrderItem(o)
    items[11] = makeItem('chest', 1, 'Collect', [o.delivered > 0 ? `${fmtK(o.delivered)} items ready` : 'Nothing to collect'])
    items[15] = makeItem('red_terracotta', 1, 'Cancel', ['Cancel this order'])
    show({
      name: 'order',
      title: 'Order',
      items,
      on: {
        11: () => setTimeout(openCollect, 120),
        15: () => setTimeout(openConfirmCancel, 120)
      }
    })
  }
  function openCollect () {
    const o = selectedOrder
    const items = new Array(27).fill(null)
    items[11] = makeItem('chest', 1, 'Take to inventory', null)
    items[15] = makeItem('emerald', 1, 'Sell', [`Sell ${fmtK(o.delivered)} items to the highest orders`])
    show({ name: 'collect', title: 'Collect Items', items, on: { 15: () => setTimeout(openConfirmSell, 120) } })
  }
  function openConfirmSell () {
    const items = new Array(27).fill(null)
    items[11] = makeItem('lime_stained_glass_pane', 1, 'Click to sell items', null)
    items[15] = makeItem('red_stained_glass_pane', 1, 'Cancel', null)
    show({
      name: 'confirmsell',
      title: 'Confirm Sell',
      items,
      on: {
        11: () => {
          const o = selectedOrder
          const proceeds = o.delivered * 70   // prodá se do nejvyšších orderů (kniha začíná na $70)
          market.balance += proceeds
          market.myOrders = market.myOrders.filter((x) => x !== o)
          market.sold.push({ ...o, proceeds })
          console.log(`[fake-mc] PRODÁNO ${o.delivered} ks z orderu ${o.id} za $${proceeds} (zůstatek $${market.balance})`)
          chat(`Sold ${o.delivered} items for $${proceeds}.`)
          closeWin()
        },
        15: () => closeWin()
      }
    })
  }
  function openConfirmCancel () {
    const items = new Array(27).fill(null)
    items[11] = makeItem('lime_stained_glass_pane', 1, 'Confirm', null)
    items[15] = makeItem('red_stained_glass_pane', 1, 'Back', null)
    show({
      name: 'confirmcancel',
      title: 'Cancel Order?',
      items,
      on: {
        11: () => {
          const o = selectedOrder
          o.canceled = true
          const refund = (o.total - o.delivered) * o.price
          market.balance += refund
          if (o.delivered === 0) market.myOrders = market.myOrders.filter((x) => x !== o)
          market.canceled.push({ ...o, refund })
          console.log(`[fake-mc] ORDER ${o.id} ZRUŠEN (vráceno $${refund}, zůstatek $${market.balance})`)
          chat('Order canceled.')
          closeWin()
        },
        15: () => closeWin()
      }
    })
  }

  function onCommand (command) {
    console.log('[fake-mc] příkaz:', '/' + command)
    if (/^orders?\s+\S/i.test(command)) setTimeout(() => openPage(1), 150)
    else if (/^orders?\s*$/i.test(command)) setTimeout(openMain, 150)
    if (/^bal\b/i.test(command)) chat(`Balance: $${market.balance.toLocaleString('en-US')}`)
  }
  client.on('chat_command', (p) => onCommand(p.command))
  client.on('chat_command_signed', (p) => onCommand(p.command))

  client.on('update_sign', (p) => {
    const text = p.text1
    console.log(`[fake-mc] cedule (${pendingInput}): "${text}"`)
    const what = pendingInput; pendingInput = null
    if (what === 'search') setTimeout(() => openSelectItem(text), 150)
    else if (what === 'amount') { draft.amount = text; setTimeout(openNewOrder, 150) }
    else if (what === 'price') { draft.price = text; setTimeout(openNewOrder, 150) }
  })

  client.on('window_click', (p) => {
    console.log(`[fake-mc] klik okno ${p.windowId} slot ${p.slot}`)
    if (p.windowId !== windowId || !cur) return
    // server klik "zruší": pošle zpět původní obsah + prázdný kurzor
    client.write('set_slot', { windowId: -1, stateId: page, slot: -1, item: Item.toNotch(null) })
    const h = cur.on[p.slot]
    if (h) h()
    else client.write('window_items', { windowId, stateId: page, items: slotsToNotch(cur.items), carriedItem: Item.toNotch(null) })
  })
  client.on('close_window', (p) => { console.log('[fake-mc] zavřeno okno', p.windowId); if (p.windowId === windowId) { windowId = 0; cur = null; page = 0 } })
  client.on('end', () => console.log('[fake-mc] odpojen', client.username))
  client.on('error', (e) => console.log('[fake-mc] chyba klienta:', e.message))
})

// ---- falešné GitHub API ----------------------------------------------------
const files = new Map()
module.exports.files = files
let puts = 0
http.createServer((req, res) => {
  let body = ''
  req.on('data', c => { body += c })
  req.on('end', () => {
    const m = req.url.match(/^\/repos\/([^/]+)\/([^/]+)\/contents\/(.+?)(\?.*)?$/)
    if (!m) { res.writeHead(404); return res.end('{}') }
    const p = m[3]
    if (req.method === 'GET') {
      if (!files.has(p)) { res.writeHead(404); return res.end(JSON.stringify({ message: 'Not Found' })) }
      const f = files.get(p)
      res.writeHead(200, { 'Content-Type': 'application/json' })
      return res.end(JSON.stringify({ sha: f.sha, content: Buffer.from(f.content).toString('base64') }))
    }
    if (req.method === 'PUT') {
      const j = JSON.parse(body)
      const existing = files.get(p)
      if (existing && j.sha !== existing.sha) { res.writeHead(409); return res.end(JSON.stringify({ message: 'sha mismatch' })) }
      const content = Buffer.from(j.content, 'base64').toString('utf8')
      const sha = 'sha' + (++puts)
      files.set(p, { sha, content })
      console.log(`[fake-gh] PUT ${p} (${content.length} B) "${j.message}"`)
      res.writeHead(existing ? 200 : 201, { 'Content-Type': 'application/json' })
      return res.end(JSON.stringify({ content: { sha } }))
    }
    res.writeHead(405); res.end()
  })
}).listen(GH_PORT, () => console.log(`[fake-gh] GitHub API napodobenina na http://127.0.0.1:${GH_PORT}`))
