// End-to-end obchodování bez internetu a účtu: falešný DonutSMP (test/fake-donut.js)
// + skutečný bot.js s obchodováním v OSTRÉM režimu proti falešnému serveru.
//   node test/trade.e2e.js          nákup (New Order flow) → naplnění → prodej (Collect → Sell) → dry-run
//   node test/trade.e2e.js cancel   zaseknutý order se po limitu zruší (Cancel → potvrzení)
'use strict';
const assert = require('assert');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const MODE = process.argv[2] === 'cancel' ? 'cancel' : 'trade';
process.env.FAKE_FILL_MS = MODE === 'cancel' ? '0' : '2500';
const fake = require('./fake-donut');

const ROOT = path.join(__dirname, '..');
const TMP_CFG = path.join(__dirname, 'trade.e2e.local.json');
const STATE = path.join(ROOT, 'data', 'trade.json');
try { fs.unlinkSync(STATE); } catch (_) { /* nebyl */ }

const baseCfg = {
  server: { host: '127.0.0.1', port: fake.MC_PORT, version: '1.21.4' },
  account: { auth: 'offline', email: 'TradeBot' },
  afterJoinDelayMs: 1000,
  cycle: { seconds: 3, jitterSeconds: 0 },
  publish: { enabled: false },
  human: { breaks: { enabled: false }, antiAfk: false, actionDelayMs: [100, 200] },
  telegram: { enabled: false },
  trade: {
    enabled: true, dryRun: false, buyBelow: 75, sellAbove: 65, buyUnits: 5000, maxOrders: 1, bidAboveTop: -1,
    priceDecimals: 1, cancelAfterMinutes: MODE === 'cancel' ? 0.03 : 0, minBalanceReserve: 1000,
  },
};

function writeCfg(extra) { fs.writeFileSync(TMP_CFG, JSON.stringify({ ...baseCfg, ...extra }, null, 2)); }

function runBot(args, opts) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(ROOT, 'bot.js'), ...args], { cwd: ROOT, env: { ...process.env, SPRUCE_CONFIG: TMP_CFG }, stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '';
    let finished = false;
    const finish = (code) => { if (finished) return; finished = true; resolve({ out, code }); };
    child.stdout.on('data', (d) => {
      out += d; process.stdout.write(d);
      if (opts.until && opts.until.test(out)) { child.stdin.write('quit\n'); setTimeout(() => { try { child.kill(); } catch (_) { /* pryč */ } }, 6000); }
    });
    child.stderr.on('data', (d) => { out += d; process.stderr.write(d); });
    child.on('exit', (code) => finish(code));
    setTimeout(() => { try { child.kill(); } catch (_) { /* pryč */ } finish(-1); }, opts.timeoutMs || 90000);
  });
}

const globalTimer = setTimeout(() => { console.error('TRADE E2E FAIL: nedokončeno včas'); process.exit(1); }, 150000);

(async () => {
  await new Promise((r) => setTimeout(r, 1200));   // falešný server naběhne
  try {
    if (MODE === 'trade') {
      // 1) OSTRÝ režim: koupit (order 2880 ks po $69 = reálný vrchol 70 − 1), počkat na naplnění, prodat
      writeCfg({});
      const r1 = await runBot([], { until: /PRODÁNO/, timeoutMs: 80000 });
      assert.ok(/ORDER VYTVOŘEN: 2\s?880 ks po \$69/.test(r1.out), 'bot vytvořil order 2880 × $69');
      assert.ok(/Zadán vstup 'spruce log' \(cedule\)/.test(r1.out), 'hledání přes ceduli');
      assert.ok(/Zadán vstup '2880' \(cedule\)/.test(r1.out) && /Zadán vstup '69' \(cedule\)/.test(r1.out), 'počet a cena přes ceduli');
      assert.strictEqual(fake.market.created.length, 1, 'na serveru vznikl jeden order');
      assert.deepStrictEqual([fake.market.created[0].item, fake.market.created[0].total, fake.market.created[0].price], ['Spruce Log', 2880, 69], 'správný item (ne Stripped), počet a cena');
      assert.ok(/PRODÁNO 2\s?880 ks/.test(r1.out), 'bot prodal naplněný order');
      assert.strictEqual(fake.market.sold.length, 1, 'server zaznamenal prodej');
      assert.strictEqual(fake.market.myOrders.length, 0, 'po prodeji žádný order');
      assert.strictEqual(fake.market.balance, 12345678 - 2880 * 69 + 2880 * 70, 'zůstatek: −nákup +prodej');
      const st = JSON.parse(fs.readFileSync(STATE, 'utf8'));
      assert.strictEqual(st.stats.trades, 1); assert.strictEqual(st.stats.bought, 2880); assert.strictEqual(st.stats.sold, 2880);
      assert.ok(Math.abs(st.stats.totalProfit - 2880) < 1, 'zisk 2880 × $1 (ze skutečného rozdílu zůstatku)');
      assert.ok(/Zůstatek: \$12\s?345\s?678/.test(r1.out), 'zůstatek přečten z /bal');
      console.log('\n[1/2] OK: nákup přes New Order (cedule ×3), naplnění, prodej přes Collect → Sell, zisk spočítán ze zůstatku.');

      // 2) TESTOVACÍ režim (--once): nic nekoupí, jen napíše, co by udělal
      writeCfg({ trade: { ...baseCfg.trade, dryRun: true } });
      const r2 = await runBot(['--once'], { timeoutMs: 60000 });
      assert.strictEqual(r2.code, 0, '--once skončí 0');
      assert.ok(/\[TEST\] Vytvořil bych order 2\s?880 ks po \$69/.test(r2.out), 'dry-run jen píše');
      assert.strictEqual(fake.market.created.length, 1, 'v dry-run nevznikl další order');
      console.log('\n[2/2] OK: testovací režim nic nekoupil.');
      console.log('\nTRADE E2E OK.');
    } else {
      // zaseknutý order: server ho nikdy nenaplní → po 0.03 min (1.8 s) bez pohybu se zruší
      writeCfg({});
      const r = await runBot([], { until: /Zrušen zaseknutý order/, timeoutMs: 80000 });
      assert.ok(/ORDER VYTVOŘEN/.test(r.out), 'order vytvořen');
      assert.ok(/RUŠÍM zaseknutý order/.test(r.out) && /Zrušen zaseknutý order/.test(r.out), 'bot zrušil zaseknutý order');
      assert.strictEqual(fake.market.canceled.length, 1, 'server zaznamenal zrušení');
      assert.strictEqual(fake.market.myOrders.length, 0, 'prázdný zrušený order zmizel');
      assert.strictEqual(fake.market.balance, 12345678, 'peníze vráceny');
      console.log('\nTRADE E2E (cancel) OK: zaseknutý order zrušen přes Cancel → potvrzení, peníze vráceny.');
    }
    clearTimeout(globalTimer);
    try { fs.unlinkSync(TMP_CFG); } catch (_) { /* nevadí */ }
    try { fs.unlinkSync(STATE); } catch (_) { /* nevadí */ }
    process.exit(0);
  } catch (e) {
    console.error('\nTRADE E2E FAIL:', e.message);
    try { fs.unlinkSync(TMP_CFG); } catch (_) { /* nevadí */ }
    process.exit(1);
  }
})();
