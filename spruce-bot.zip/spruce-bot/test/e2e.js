// End-to-end bez internetu a účtu: spustí falešný DonutSMP + falešné GitHub API
// (test/fake-donut.js) a skutečný bot.js v režimu --dump (offline účet) jako
// samostatný proces. Ověří přihlášení, /orders spruce log, 3 stránky, upload.
// Spuštění:  node test/e2e.js          (FAKE_INPLACE=1 = stránkování přepisem okna)
'use strict';
const assert = require('assert');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const fake = require('./fake-donut');

const ROOT = path.join(__dirname, '..');
const TMP_CFG = path.join(__dirname, 'e2e.local.json');

fs.writeFileSync(TMP_CFG, JSON.stringify({
  server: { host: '127.0.0.1', port: fake.MC_PORT, version: '1.21.4' },
  account: { auth: 'offline', email: 'E2EBot' },
  afterJoinDelayMs: 1500,
  publish: { enabled: true, owner: 'marek', repo: 'spruce-data', token: 'TOKEN', apiBase: `http://127.0.0.1:${fake.GH_PORT}`, uploadDump: true },
  human: { breaks: { enabled: false }, antiAfk: true, antiAfkSeconds: 3, actionDelayMs: [200, 400] },
  telegram: { enabled: false },
}, null, 2));

const timeout = setTimeout(() => { console.error('E2E FAIL: nedokončeno do 90 s'); process.exit(1); }, 90000);

setTimeout(() => {
  const child = spawn(process.execPath, [path.join(ROOT, 'bot.js'), '--dump'], {
    cwd: ROOT,
    env: { ...process.env, SPRUCE_CONFIG: TMP_CFG },
    stdio: ['pipe', 'pipe', 'pipe'],
  });
  let out = '';
  child.stdout.on('data', (d) => { out += d; process.stdout.write(d); });
  child.stderr.on('data', (d) => { out += d; });
  child.on('exit', (code) => {
    try {
      assert.strictEqual(code, 0, 'bot.js --dump má skončit kódem 0');
      assert.ok(/Vanilla mimikry zapnuty/.test(out), 'mimikry');
      assert.ok(/stránka 3 .*\(poslední\)/.test(out), 'přečteny 3 stránky');
      assert.ok(/reálný vrchol \$70 \(≥25\s?000 ks\) \| nejlepší \$70 \(259\s?000 ks\)/.test(out), 'souhrn');
      const f = fake.files.get('prices.json');
      assert.ok(f, 'prices.json nahrán');
      const j = JSON.parse(f.content);
      assert.strictEqual(j.status, 'ok');
      assert.strictEqual(j.count, 103);
      assert.strictEqual(j.pages_read, 3);
      assert.strictEqual(j.best, 70);
      assert.strictEqual(j.effective_top, 70);
      assert.strictEqual(j.truncated, false);
      assert.ok(j.demand_real > 0 && j.count_real === 103);
      assert.ok(fake.files.has('debug/sprucelog-gui.json'), 'dump GUI nahrán');
      assert.ok(fs.existsSync(path.join(ROOT, 'data', 'history-sprucelog.json')), 'lokální historie');
      console.log('\nE2E OK: přihlášení, kniha přes 3 stránky, upload prices.json + dump GUI.');
      clearTimeout(timeout);
      try { fs.unlinkSync(TMP_CFG); } catch (_) { /* nevadí */ }
      process.exit(0);
    } catch (e) {
      console.error('\nE2E FAIL:', e.message);
      try { fs.unlinkSync(TMP_CFG); } catch (_) { /* nevadí */ }
      process.exit(1);
    }
  });
}, 1500);
