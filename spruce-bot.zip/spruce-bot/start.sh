#!/usr/bin/env bash
# Spouštěč pro Termux / Linux: drží wake lock, doinstaluje závislosti, po pádu restartuje.
cd "$(dirname "$0")"
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
if [ ! -d node_modules ]; then
  echo "První spuštění – instaluji závislosti…"
  npm install --no-audit --no-fund
fi
while true; do
  node bot.js
  code=$?
  if [ "$code" -eq 0 ]; then break; fi
  echo
  echo "Bot skončil s chybou (kód $code) – restartuji za 15 s… (Ctrl+C = konec)"
  sleep 15
done
