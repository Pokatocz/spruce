#!/usr/bin/env node
// ============================================================
//  SPRUCE BOT – samostatný bot pro DonutSMP: čte ceny z /orders,
//  publikuje je na web (GitHub Pages) a volitelně obchoduje
//  (kup pod X, prodej nad Y – sekce trade v configu, testovací režim výchozí).
//
//  node bot.js --setup        průvodce: účet, GitHub, Telegram (→ config.local.json)
//  node bot.js --test-github  ověří token a zápis do repa
//  node bot.js --dump         jedno čtení + celý výpis menu (poprvé přihlášení kódem)
//  node bot.js --once         jedno čtení + upload a konec
//  node bot.js                běží pořád (Termux: bash start.sh, Windows: start.bat)
//  Ovládání: piš příkazy do konzole – začni  help
// ============================================================
'use strict';
process.noDeprecation = true;   // potlačí varování z knihoven (punycode apod.)

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const mineflayer = require('mineflayer');
const log = require('./lib/logger');
const notify = require('./lib/notify');
const gui = require('./lib/gui');
const trade = require('./lib/trade');
const { Publisher } = require('./lib/publish');
const { sleep, randInt, humanDelay, jitter, toPlain, initChat, fmtNum, median, isPriceSane, gracefulExit } = require('./lib/util');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const LOCAL_CFG = process.env.SPRUCE_CONFIG || path.join(ROOT, 'config.local.json');
const CRASH_MARKER = path.join(DATA_DIR, 'crash.json');

// ---------- konfigurace ----------
function deepMerge(base, extra) {
  const out = Array.isArray(base) ? base.slice() : { ...base };
  for (const [k, v] of Object.entries(extra || {})) {
    if (v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k])) out[k] = deepMerge(out[k], v);
    else out[k] = v;
  }
  return out;
}

function loadConfig() {
  let cfg = require('./config');
  if (fs.existsSync(LOCAL_CFG)) {
    try { cfg = deepMerge(cfg, JSON.parse(fs.readFileSync(LOCAL_CFG, 'utf8'))); }
    catch (e) { console.error('config.local.json nejde přečíst: ' + e.message); }
  }
  if (process.env.GITHUB_TOKEN) cfg.publish.token = process.env.GITHUB_TOKEN;
  if (process.env.MC_ACCOUNT) cfg.account.email = process.env.MC_ACCOUNT;
  return cfg;
}

// ---------- průvodce nastavením ----------
async function setupWizard() {
  const rl = readline.createInterface({ input: process.stdin, terminal: false });
  const lines = [];
  let closed = false;
  rl.on('line', (l) => lines.push(l));
  rl.on('close', () => { closed = true; });
  const ask = async (q, def) => {
    process.stdout.write(`${q}${def ? ` [${def}]` : ''}: `);
    while (!lines.length && !closed) await sleep(50);
    const a = lines.length ? lines.shift() : '';
    if (closed && !lines.length) process.stdout.write('\n');
    return (a || '').trim() || def || '';
  };
  let cur = {};
  try { cur = JSON.parse(fs.readFileSync(LOCAL_CFG, 'utf8')); } catch (_) { cur = {}; }
  console.log('\n=== Nastavení bota (Enter = ponechat hodnotu v závorce) ===\n');
  const email = await ask('E-mail Microsoft účtu s Minecraftem (bot)', cur.account && cur.account.email);
  const hadWeb = !!(cur.publish && cur.publish.owner);
  const wantWeb = /^a|^y|^1/i.test(await ask('Publikovat ceny na vlastní web přes GitHub? (a/n)', hadWeb ? 'a' : 'n'));
  let owner = cur.publish && cur.publish.owner;
  let repo = (cur.publish && cur.publish.repo) || 'spruce-data';
  let token = cur.publish && cur.publish.token;
  if (wantWeb) {
    owner = await ask('GitHub uživatelské jméno', owner);
    repo = await ask('GitHub repo s daty', repo);
    token = await ask('GitHub token (github_pat_…)', token);
  }
  const tgToken = await ask('Telegram bot token (Enter = bez Telegramu)', cur.telegram && cur.telegram.token);
  let tgChat = cur.telegram && cur.telegram.chatId;
  if (tgToken) tgChat = await ask('Telegram chat ID (Enter = zjistím později příkazem tgid)', tgChat);
  rl.close();
  const next = deepMerge(cur, {
    account: { email },
    publish: { enabled: wantWeb, owner: owner || '', repo, token: token || '' },
    telegram: { enabled: !!(tgToken && tgChat), token: tgToken || '', chatId: tgChat || '' },
  });
  fs.writeFileSync(LOCAL_CFG, JSON.stringify(next, null, 2) + '\n');
  console.log(`\nUloženo do ${LOCAL_CFG}.`);
  console.log('Obchodování (kup pod / prodej nad) nastavíš na webu v konfigurátoru – stažený config.local.json dej do této složky.');
  console.log(`Další krok:  ${wantWeb ? 'node bot.js --test-github   a pak   ' : ''}node bot.js --dump\n`);
}

// ---------- hlavní program ----------
function main(cfg, flags) {
  const publisher = new Publisher(cfg);
  const state = {
    bot: null,
    connected: false,
    spawned: false,
    running: false,      // právě probíhá kolo
    stopping: false,
    sleeping: false,     // mimo aktivní hodiny
    onBreak: false,      // náhodná přestávka
    banned: false,
    reconnects: 0,
    lastKick: null,
    cycles: 0,
    lastCycleAt: 0,
    lastResult: new Map(),
    guiStuckStreak: 0,
    nextCycleDueAt: Date.now() + 10 * 60000,
  };
  // obchodování: sdílený stav (dry-run se dá přepnout za běhu příkazem  dry on|off)
  const ts = { dryRun: !(cfg.trade && cfg.trade.dryRun === false), balance: NaN, lastOrders: null, lastSummary: null };
  const tradeOn = () => !!(cfg.trade && cfg.trade.enabled);
  const tradeItem = () => (cfg.watch || [])[0] || null;
  const timers = [];        // globální (watchdog, aktivní hodiny)
  let connTimers = [];      // na jedno připojení (anti-AFK)
  let cycleTimer = null;
  let kickTimes = [];
  let lastKickAlert = 0;

  // ---- vanilla mimikry: tick_end + player_loaded (anti-bot „Invalid sequence") ----
  function attachVanillaMimic(b) {
    let canTick = null;
    let canLoaded = null;
    const detect = () => {
      try {
        const types = require('minecraft-data')(b.version).protocol.play.toServer.types;
        canTick = !!types.packet_tick_end;
        canLoaded = !!types.packet_player_loaded;
        if (canTick) log.info(`Vanilla mimikry zapnuty (verze ${b.version}: tick_end${canLoaded ? ' + player_loaded' : ''}).`);
      } catch (_) { canTick = false; canLoaded = false; }
    };
    b.on('spawn', () => {
      if (canLoaded === null) detect();
      if (canLoaded) { try { b._client.write('player_loaded', {}); } catch (_) { canLoaded = false; } }
    });
    b.on('physicsTick', () => {
      if (canTick === null) detect();
      if (canTick) { try { b._client.write('tick_end', {}); } catch (_) { canTick = false; } }
    });
  }

  // ---- aktivní hodiny ----
  function inActiveHours() {
    const ah = cfg.human && cfg.human.activeHours;
    if (!ah || !ah.enabled) return true;
    const h = new Date().getHours();
    return ah.from <= ah.to ? (h >= ah.from && h < ah.to) : (h >= ah.from || h < ah.to);
  }

  function checkActiveHours() {
    const ah = cfg.human && cfg.human.activeHours;
    if (!ah || !ah.enabled || state.stopping) return;
    const active = inActiveHours();
    if (!active && !state.sleeping) {
      state.sleeping = true;
      log.info(`Aktivní hodiny skončily (${ah.from}:00–${ah.to}:00) – bot jde spát, odpojuji se.`);
      publisher.heartbeatAll('sleeping', `Bot spí – aktivní hodiny ${ah.from}:00–${ah.to}:00`).catch(() => {});
      notify.event(cfg, 'sleep', `😴 Bot jde spát (aktivní hodiny ${ah.from}–${ah.to}).`).catch(() => {});
      try { if (state.bot) state.bot.quit(); } catch (_) { /* pryč */ }
    } else if (active && state.sleeping) {
      state.sleeping = false;
      state.reconnects = 0;
      log.ok('Aktivní hodiny začaly – připojuji se.');
      setTimeout(() => { if (!state.stopping && !state.sleeping) connect(); }, randInt(3, 40) * 1000);
    }
  }

  // ---- kicky a bany ----
  function registerKick(text) {
    const now = Date.now();
    kickTimes = kickTimes.filter((t) => now - t < 3600000);
    kickTimes.push(now);
    if (/invalid sequence|invalid|kicked for/i.test(text) && kickTimes.length >= 4 && now - lastKickAlert > 30 * 60000) {
      lastKickAlert = now;
      log.warn(`Anti-bot kick už ${kickTimes.length}× za hodinu.`);
      notify.event(cfg, 'kicks', `⚠️ Bota za poslední hodinu ${kickTimes.length}× vyhodil server (${text.slice(0, 120)}). Zvaž pauzu.`).catch(() => {});
    }
  }

  // ---- watchdog: pád / zamrznutí → exit(1), start.sh/start.bat restartuje ----
  let fatalRunning = false;
  async function fatal(reason) {
    if (fatalRunning) return;
    fatalRunning = true;
    log.err('FATÁLNÍ CHYBA: ' + reason);
    try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(CRASH_MARKER, JSON.stringify({ t: Date.now(), reason: String(reason).slice(0, 300) })); } catch (_) { /* nevadí */ }
    try { await Promise.race([notify.event(cfg, 'crash', `🔴 Bot spadl (${String(reason).slice(0, 180)}) – restartuje se.`), sleep(6000)]); } catch (_) { /* nevadí */ }
    process.exit(1);
  }
  process.on('uncaughtException', (e) => fatal('uncaughtException: ' + ((e && e.stack) || e)));
  process.on('unhandledRejection', (e) => fatal('unhandledRejection: ' + ((e && e.stack) || e)));
  if (!flags.once) {
    timers.push(setInterval(() => {
      if (state.stopping || state.sleeping || state.onBreak || !state.connected) return;
      const graceMs = ((cfg.cycle.seconds + cfg.cycle.jitterSeconds) * 3 + 300) * 1000;
      const overdue = Date.now() - state.nextCycleDueAt;
      if (overdue > graceMs) fatal(`zamrznutí – kolo je ${Math.round(overdue / 60000)} min po termínu`);
    }, 60000));
  }

  // ---- připojení ----
  function connect() {
    if (state.stopping || state.banned) return;
    log.info(`Připojuji se na ${cfg.server.host}:${cfg.server.port} (verze ${cfg.server.version}) …`);
    const bot = mineflayer.createBot({
      host: cfg.server.host,
      port: cfg.server.port,
      version: cfg.server.version,
      auth: cfg.account.auth || 'microsoft',
      username: cfg.account.email || 'spruce-bot',
      profilesFolder: path.join(ROOT, 'auth-cache'),
      viewDistance: 'tiny',
      checkTimeoutInterval: 90000,
      hideErrors: true,
      onMsaCode: (data) => {
        console.log('\n**************************************************************');
        console.log('  PŘIHLÁŠENÍ MICROSOFT ÚČTU (jen poprvé):');
        console.log('  1) Otevři v prohlížeči:  ' + data.verification_uri);
        console.log('  2) Zadej kód:            ' + data.user_code);
        console.log('  Pak se bot přihlásí sám a přihlášení si zapamatuje (auth-cache/).');
        console.log('**************************************************************\n');
      },
    });
    state.bot = bot;
    state.connected = false;
    state.spawned = false;
    initChat(bot.registry || cfg.server.version);
    attachVanillaMimic(bot);
    trade.attachSignHandler(bot);   // cedule = políčka pro hledání / počet / cenu

    bot.once('login', () => {
      state.connected = true;
      state.reconnects = 0;
      log.ok(`Přihlášen jako ${bot.username}`);
    });

    bot.once('spawn', async () => {
      state.spawned = true;
      log.ok('Bot je ve světě.');
      await sleep(cfg.afterJoinDelayMs || 5000);
      if (cfg.human && cfg.human.antiAfk) {
        connTimers.push(setInterval(() => {
          if (!state.connected || state.running || state.bot !== bot) return;
          try {
            bot.look((Math.random() * 2 - 1) * Math.PI, (Math.random() * 0.4 - 0.2), false);
            if (Math.random() < 0.3) bot.swingArm('right');
          } catch (_) { /* nevadí */ }
        }, jitter((cfg.human.antiAfkSeconds || 50) * 1000, 0.3)));
      }
      scheduleCycle(randInt(4, 12));
    });

    bot.on('resourcePack', () => {
      log.info('Server poslal resource pack – přijímám.');
      try { bot.acceptResourcePack(); } catch (_) { /* nevadí */ }
    });

    // Veřejný chat na Donutu chodí jako „system" zprávy ve tvaru "<hráč> text" –
    // v režimu 'system' se přeskakuje, aby konzole nebyla zaplavená spamem.
    bot.on('message', (jsonMsg, position) => {
      const mode = (cfg.behavior && cfg.behavior.chatLog) || 'system';
      if (mode === 'none') return;
      const text = toPlain(jsonMsg);
      if (!text) return;
      const playerChat = position === 'chat' || /^<[^>]{1,48}>\s/.test(text);
      if (mode === 'system' && playerChat) return;
      log.chat(`<${position}> ${text}`);
      console.log(`  <${position}> ${text.slice(0, 200)}`);
    });

    bot.on('kicked', (reason) => {
      const text = toPlain(reason) || String(reason);
      state.lastKick = text;
      log.err('Server bota vyhodil: ' + text);
      if (/banned|\bban\b|blacklist/i.test(text)) {
        state.banned = true;
        log.err('Vypadá to na BAN – bot se nebude znovu připojovat. Zkontroluj účet.');
        publisher.heartbeatAll('error', 'Bot vyhozen: ' + text.slice(0, 120)).catch(() => {});
        notify.event(cfg, 'ban', `⛔ Bot vyhozen (možný ban): ${text.slice(0, 200)}`).catch(() => {});
      } else registerKick(text);
    });

    bot.on('error', (e) => log.err('Chyba spojení: ' + (e && e.message ? e.message : e)));

    bot.on('end', (reason) => {
      state.connected = false;
      state.spawned = false;
      for (const t of connTimers) clearInterval(t);
      connTimers = [];
      if (cycleTimer) { clearTimeout(cycleTimer); cycleTimer = null; }
      if (state.stopping || state.sleeping || state.onBreak || state.banned) return;
      if (flags.once) { log.err('Spojení ukončeno před dokončením čtení.'); shutdown(1); return; }
      if (!(cfg.behavior && cfg.behavior.reconnect)) { log.warn('Spojení ukončeno, automatické připojení je vypnuté.'); return; }
      state.reconnects++;
      // „already online" = proxy ještě drží starou session; krátké pokusy ji jen
      // udržují naživu → čekat déle (3–15 min). Jinak eskalace 45 s → 3 min.
      let base = (cfg.behavior.reconnectDelaySeconds || 45);
      let capMult = 4;
      if (state.lastKick && /already online|already connected|request-join-cache/i.test(state.lastKick)) { base = Math.max(base, 180); capMult = 5; }
      const wait = base * Math.min(state.reconnects, capMult) + randInt(0, 30);
      state.lastKick = null;
      log.warn(`Spojení ukončeno (${reason}). Nové připojení za ${wait} s (pokus č. ${state.reconnects}).`);
      setTimeout(() => { if (!state.stopping && !state.sleeping && !state.onBreak) connect(); }, wait * 1000);
    });
  }

  // ---- kola ----
  function scheduleCycle(overrideSeconds) {
    if (cycleTimer) clearTimeout(cycleTimer);
    let delay;
    if (overrideSeconds !== undefined) delay = overrideSeconds;
    else {
      const br = cfg.human && cfg.human.breaks;
      if (br && br.enabled && !state.onBreak && Math.random() < (br.chancePerCycle || 0)) {
        const mins = randInt(br.minMinutes || 3, br.maxMinutes || 10);
        log.info(`Dávám si přestávku ~${mins} min – odpojuji se (jako když si člověk odskočí).`);
        state.onBreak = true;
        state.nextCycleDueAt = Date.now() + mins * 60000 + 120000;
        publisher.heartbeatAll('break', `Bot má přestávku ~${mins} min`).catch(() => {});
        try { if (state.bot) state.bot.quit(); } catch (_) { /* pryč */ }
        setTimeout(() => {
          state.onBreak = false;
          if (!state.stopping && !state.sleeping) { state.reconnects = 0; log.ok('Přestávka skončila – připojuji se zpět.'); connect(); }
        }, mins * 60000);
        return;
      }
      delay = cfg.cycle.seconds + randInt(0, cfg.cycle.jitterSeconds || 0);
    }
    state.nextCycleDueAt = Date.now() + delay * 1000;
    if (overrideSeconds === undefined) log.info(`Další čtení za ${delay} s.`);
    cycleTimer = setTimeout(() => runCycle().catch((e) => log.err('Kolo selhalo: ' + e.message)), delay * 1000);
  }

  async function runCycle(manual = false) {
    if (!manual && !inActiveHours()) { scheduleCycle(); return; }
    if (!state.connected || !state.spawned) { if (!manual) scheduleCycle(); return; }
    if (state.running) return;
    state.running = true;
    let anyOk = false;
    try {
      log.info('--- Čtení cen ---');
      for (const w of cfg.watch || []) {
        let result = null;
        try {
          result = await gui.readBook(state.bot, cfg, w);
        } catch (e) {
          log.warn(`${w.match}: ${e.message}`);
          await gui.ensureClosed(state.bot);
        }
        if (result) {
          anyOk = true;
          const best = result.orders.length ? Math.max(...result.orders.map((o) => o.price)) : NaN;
          const recent = loadHistory(w.key).slice(-12).map((r) => r.best);
          const suspect = Number.isFinite(best) && !isPriceSane(best, recent, 3);
          if (suspect) log.warn(`${w.match}: nejlepší cena ${fmtNum(best)} je daleko od nedávného mediánu ${fmtNum(median(recent))} – nejspíš troll order (označeno).`);
          const snap = await publisher.publishBook(w, result, { suspect, forceDump: flags.dump });
          if (snap) {
            appendHistory(w.key, { t: Date.now(), best: snap.best, eff: snap.effective_top, top5: snap.top5_avg, median: snap.median_real, count: snap.count_real, demand: snap.demand_real });
            state.lastResult.set(w.key, snap);
            log.ok(`${w.match}: reálný vrchol $${snap.effective_top} (≥${fmtNum(snap.effective_min_demand)} ks) | nejlepší $${snap.best} (${fmtNum(snap.best_remaining)} ks) | vážený Ø reálných $${snap.weighted_avg_real} | ${snap.count_real}/${snap.count} orderů | reálná poptávka ${fmtNum(snap.demand_real)} ks | ${snap.pages_read} str.`);
          }
          if (flags.dump) printDump(result.dumps);
          // obchodování (jen první sledovaný item; podezřelou cenu neobchodovat)
          if (tradeOn() && w === tradeItem() && !flags.dump && state.connected) {
            if (suspect) log.warn(`${w.match}: cena vypadá podezřele – v tomto kole neobchoduji.`);
            else {
              try {
                await trade.runTrading(state.bot, cfg, w, result.orders, snap ? snap.effective_top : NaN, ts);
              } catch (e) {
                log.err('Obchodování selhalo: ' + e.message);
                await gui.ensureClosed(state.bot);
              }
            }
          }
        } else {
          await publisher.heartbeat(w, 'error', 'Kniha orderů se nepodařila otevřít (fronta / lag?)');
        }
        await humanDelay(cfg);
      }
      state.cycles++;
      state.lastCycleAt = Date.now();
      // samoléčba: menu se opakovaně neotvírají → přepojit
      if (anyOk) state.guiStuckStreak = 0;
      else {
        state.guiStuckStreak++;
        log.warn(`Menu se v tomto kole neotevřelo (${state.guiStuckStreak}× po sobě).`);
        if (state.guiStuckStreak >= (cfg.cycle.guiStuckLimit || 2)) {
          state.guiStuckStreak = 0;
          log.warn('Menu se opakovaně neotvírají – přepojuji bota (samoléčba).');
          notify.event(cfg, 'stuck', 'Menu se přestala otevírat, přepojuji bota (samoléčba).').catch(() => {});
          try { if (state.bot) state.bot.quit(); } catch (_) { /* pryč */ }
        }
      }
      log.info('--- Hotovo ---');
    } finally {
      state.running = false;
      if (flags.once) { shutdown(anyOk ? 0 : 1); return; }
      if (!manual) scheduleCycle();
    }
  }

  function printDump(dumps) {
    for (const d of dumps || []) {
      console.log(`\n=== ${d.title} (${d.type}) ===`);
      for (const s of d.slots) {
        console.log(`  [${String(s.slot).padStart(2)}] ${s.type} x${s.count}  "${s.name}"`);
        for (const l of s.lore) if (l) console.log(`        ${l}`);
      }
    }
    console.log('');
  }

  // ---- lokální historie (pro filtr příčetnosti a příkaz historie) ----
  function histFile(key) { return path.join(DATA_DIR, `history-${key}.json`); }
  function loadHistory(key) { try { return JSON.parse(fs.readFileSync(histFile(key), 'utf8')); } catch (_) { return []; } }
  function appendHistory(key, rec) {
    try {
      const h = loadHistory(key);
      h.push(rec);
      while (h.length > 2000) h.shift();
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(histFile(key), JSON.stringify(h));
      log.priceCsv(key, rec);
    } catch (e) { log.warn('historie: ' + e.message); }
  }

  // ---- konzole ----
  const HELP = `
Příkazy:
  help        nápověda                 status     stav bota, webu a obchodování
  cyklus      hned přečíst ceny        historie   poslední měření
  web         ověřit zápis do GitHubu  tg [text]  test Telegramu   tgid  zjistit chat ID
  okno        vypsat otevřené menu     klik <název|slot>   kliknout v menu (ladění)
  input <text>  vyplnit políčko        seq a > b > input:x   proklikat sekvenci (mapování GUI)
  cmd </…>    poslat příkaz            say <text>  napsat do chatu
  quit        ukončit bota

Obchodování (sekce trade v configu / konfigurátor na webu):
  obchod on|off   zapnout/vypnout       dry on|off   testovací režim (off = OSTRÝ, kupuje doopravdy!)
  ordery          moje ordery na serveru   bal       zůstatek (/bal)      profit   celkový zisk
  kup <ks> [cena] ručně vytvořit order (bez ceny: reálný vrchol + bidAboveTop)
  prodej [slot]   prodat naplněný order    zrus <slot>   zrušit order (slot z  ordery)
`;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: '> ' });
  rl.on('line', async (line) => {
    const [c, ...rest] = line.trim().split(/\s+/);
    const arg = rest.join(' ');
    try {
      switch ((c || '').toLowerCase()) {
        case '': break;
        case 'help': console.log(HELP); break;
        case 'status': {
          const age = state.lastCycleAt ? Math.round((Date.now() - state.lastCycleAt) / 60000) : null;
          console.log(`Připojení: ${state.connected ? 'ANO (' + (state.bot && state.bot.username) + ')' : 'NE'}${state.sleeping ? ' – spí' : ''}${state.onBreak ? ' – přestávka' : ''}${state.banned ? ' – BAN?' : ''}`);
          console.log(`Kol: ${state.cycles} | poslední čtení: ${age === null ? 'zatím žádné' : 'před ' + age + ' min'} | další za ${Math.max(0, Math.round((state.nextCycleDueAt - Date.now()) / 1000))} s`);
          for (const [, s] of state.lastResult) console.log(`  ${s.item_name}: reálný vrchol $${s.effective_top}, nejlepší $${s.best}, vážený Ø $${s.weighted_avg_real}, ${s.count_real}/${s.count} orderů, reálná poptávka ${fmtNum(s.demand_real)}`);
          console.log(publisher.statusLine());
          if (tradeOn()) {
            const t = cfg.trade;
            const st = trade.loadState();
            console.log(`Obchodování: ZAPNUTO – ${ts.dryRun ? 'TESTOVACÍ režim (nic nekupuje)' : 'OSTRÝ režim'} | kup pod $${t.buyBelow}, prodej nad $${t.sellAbove}, ${fmtNum(trade.normalizeUnits(t.buyUnits))} ks/order, max ${t.maxOrders} orderů`);
            console.log(`  Zůstatek: ${Number.isFinite(ts.balance) ? '$' + fmtNum(ts.balance) : 'neznámý'} | ordery: ${ts.lastOrders ? ts.lastOrders.length + ' (' + ts.lastOrders.filter((o) => o.completed).length + ' naplněných)' : 'zatím nečteny'} | zisk celkem $${fmtNum(Math.round((st.stats || {}).totalProfit || 0))} (${(st.stats || {}).trades || 0} prodejů)`);
          } else console.log('Obchodování: vypnuto (trade.enabled: false)');
          break;
        }
        case 'obchod': {
          if (!/^(on|off|zap|vyp)/i.test(arg)) { console.log(`Obchodování je ${tradeOn() ? 'zapnuté' : 'vypnuté'}. Použití: obchod on | obchod off`); break; }
          cfg.trade = cfg.trade || {};
          cfg.trade.enabled = /^(on|zap)/i.test(arg);
          console.log(`Obchodování ${cfg.trade.enabled ? 'ZAPNUTO' : 'VYPNUTO'} (do restartu; trvale v config.local.json → trade.enabled).`);
          break;
        }
        case 'dry': {
          if (!/^(on|off)/i.test(arg)) { console.log(`Režim: ${ts.dryRun ? 'TESTOVACÍ (dry-run)' : 'OSTRÝ'}. Použití: dry on | dry off`); break; }
          ts.dryRun = /^on/i.test(arg);
          console.log(ts.dryRun ? 'Testovací režim ZAPNUT – bot nic nekupuje ani neprodává.' : '!!! OSTRÝ REŽIM – bot bude doopravdy vytvářet ordery a prodávat (do restartu; trvale trade.dryRun: false).');
          break;
        }
        case 'ordery': {
          const w = tradeItem();
          if (!w || !state.connected) { console.log('Bot není připojený.'); break; }
          const my = await trade.scanMyOrders(state.bot, cfg, w);
          ts.lastOrders = my;
          if (!my.length) console.log(`Žádné ordery ${w.match} v „Your Orders".`);
          for (const o of my) console.log(`  slot ${String(o.slot).padStart(2)} | ${fmtNum(o.delivered)}/${fmtNum(o.total)} ks po $${fmtNum(o.price)}${o.completed ? ' | NAPLNĚN – jde prodat' : ''}${o.canceled ? ' | zrušen' : ''}`);
          break;
        }
        case 'bal': {
          if (!state.connected) { console.log('Bot není připojený.'); break; }
          const b = await trade.refreshBalance(state.bot, cfg);
          if (b !== null) ts.balance = b;
          console.log(b !== null ? `Zůstatek: $${fmtNum(b)}` : 'Zůstatek se nepodařilo přečíst (zkontroluj trade.balanceRegex podle logs/chat.log).');
          break;
        }
        case 'profit': {
          const s = trade.loadState().stats || {};
          console.log(`Celkový zisk: $${fmtNum(Math.round(s.totalProfit || 0))} | prodejů: ${s.trades || 0} | nakoupeno ${fmtNum(s.bought || 0)} ks | prodáno ${fmtNum(s.sold || 0)} ks`);
          break;
        }
        case 'kup': {
          const w = tradeItem();
          if (!w || !state.connected) { console.log('Bot není připojený.'); break; }
          const amount = trade.normalizeUnits(rest[0]);
          let price = parseFloat(rest[1]);
          if (!Number.isFinite(price)) {
            const s = state.lastResult.get(w.key);
            const top = s && Number.isFinite(s.effective_top) ? s.effective_top : NaN;
            if (!Number.isFinite(top)) { console.log('Neznám cenu – nejdřív  cyklus , nebo zadej cenu:  kup 2880 59'); break; }
            price = top + (cfg.trade && cfg.trade.bidAboveTop !== undefined ? Number(cfg.trade.bidAboveTop) : 1);
          }
          if (!rest[0]) { console.log('Použití: kup <počet kusů> [cena za kus]   (počet se zaokrouhlí na celé stránky = násobky 2880)'); break; }
          if (ts.dryRun) { console.log(`[TEST] Vytvořil bych order ${fmtNum(amount)} ks po $${fmtNum(price)} (≈ $${fmtNum(amount * price)}). Ostrý režim:  dry off`); break; }
          await trade.createOrder(state.bot, cfg, w, amount, price);
          log.ok(`Ručně vytvořen order: ${fmtNum(amount)} ks po $${fmtNum(price)}`);
          break;
        }
        case 'prodej': {
          const w = tradeItem();
          if (!w || !state.connected) { console.log('Bot není připojený.'); break; }
          const my = await trade.scanMyOrders(state.bot, cfg, w);
          ts.lastOrders = my;
          let target = null;
          if (arg) target = my.find((o) => String(o.slot) === arg.trim());
          else target = my.filter((o) => o.completed).sort((a, b) => (a.price || 0) - (b.price || 0))[0];
          if (!target) { console.log(arg ? `Order ve slotu ${arg} není.` : 'Žádný naplněný order k prodeji (viz  ordery).'); break; }
          if (ts.dryRun) { console.log(`[TEST] Prodal bych order slot ${target.slot} (${fmtNum(target.delivered)} ks po $${fmtNum(target.price)}). Ostrý režim:  dry off`); break; }
          await trade.sellOrder(state.bot, cfg, w, target.slot);
          log.ok(`Ručně prodán order slot ${target.slot} (${fmtNum(target.delivered)} ks, nákup po $${fmtNum(target.price)}).`);
          break;
        }
        case 'zrus': case 'zruš': {
          const w = tradeItem();
          const slot = parseInt(arg, 10);
          if (!w || !state.connected) { console.log('Bot není připojený.'); break; }
          if (!Number.isFinite(slot)) { console.log('Použití: zrus <slot>   (slot zjistíš příkazem  ordery)'); break; }
          if (ts.dryRun) { console.log(`[TEST] Zrušil bych order ve slotu ${slot}. Ostrý režim:  dry off`); break; }
          await trade.cancelOrder(state.bot, cfg, w, slot);
          log.ok(`Order ve slotu ${slot} zrušen.`);
          break;
        }
        case 'input': {
          if (!arg || !state.bot) { console.log('Použití: input <text>   (např.  input 2880)'); break; }
          const mode = await trade.doInput(state.bot, arg);
          console.log(`Zadáno přes: ${mode}`);
          await sleep(1200);
          console.log(gui.dumpText(state.bot.currentWindow));
          break;
        }
        case 'seq': {
          // Proklikne sekvenci NARÁZ (server jinak okno po chvíli zavře). Kroky odděl znakem >.
          // Text zadáš jako  input:text.  Např.:  seq chest > New Order > Item > Search > input:spruce log
          if (!state.bot || !state.connected) { console.log('Bot není připojený.'); break; }
          const steps = arg.split('>').map((s) => s.trim()).filter(Boolean);
          if (!steps.length) { console.log('Použití: seq chest > New Order > Item > Search > input:spruce log'); break; }
          let openCmd = (cfg.trade && cfg.trade.openCommand) || '/orders';
          if (steps[0].startsWith('/')) openCmd = steps.shift();
          await gui.openByCommand(state.bot, cfg, openCmd);
          for (const s of steps) {
            if (/^input:/i.test(s)) {
              const txt = s.slice(6);
              const mode = await trade.doInput(state.bot, txt);
              console.log(`  · vstup '${txt}' (${mode})`);
              await sleep(1500);
              continue;
            }
            if (/^wait:/i.test(s)) { const ms = parseInt(s.slice(5), 10) || 1000; await sleep(ms); continue; }
            const win = state.bot.currentWindow;
            if (!win) { console.log(`  Okno se zavřelo před krokem '${s}'.`); break; }
            const target = trade.findInWindow(win, s) || trade.findInWindow(win, null, s);
            if (!target) { console.log(`  Krok '${s}' v okně "${gui.windowTitle(win)}" nenalezen. Je tam: ${gui.containerSlots(win).map((x) => x.name || x.type).slice(0, 25).join(', ')}`); break; }
            console.log(`  · klik '${s}' (slot ${target.slot})`);
            await state.bot.clickWindow(target.slot, 0, 0);
            for (let i = 0; i < 20 && !state.bot.currentWindow; i++) await sleep(300);
            await sleep(800);
          }
          console.log('--- co je teď otevřené: ---');
          console.log(gui.dumpText(state.bot.currentWindow));
          break;
        }
        case 'cyklus': await runCycle(true); break;
        case 'historie': {
          for (const w of cfg.watch || []) {
            const h = loadHistory(w.key);
            console.log(`${w.match}: ${h.length} záznamů (logs/trh-${w.key}.csv)`);
            for (const r of h.slice(-8)) console.log(`  ${new Date(r.t).toLocaleString('cs-CZ')}  reálný vrchol ${fmtNum(r.eff)}  nejlepší ${fmtNum(r.best)}  reálných orderů ${r.count}  reálná poptávka ${fmtNum(r.demand)}`);
          }
          break;
        }
        case 'web': {
          try { console.log(await publisher.selfTest()); }
          catch (e) { console.log('Zápis do GitHubu selhal: ' + e.message + '  (403 = token nemá Contents: Read and write, 404 = špatný owner/repo)'); }
          break;
        }
        case 'tg': case 'test': {
          const ok = await notify.send(cfg, arg || 'Test ze spruce-botu – Telegram funguje ✅');
          console.log(ok ? 'Odesláno.' : 'Neodesláno – zkontroluj telegram.token / chatId (node bot.js --setup).');
          break;
        }
        case 'tgid': {
          const id = await notify.getChatId(cfg);
          console.log(id ? `Tvoje Telegram chat ID: ${id}  → ulož přes  node bot.js --setup` : 'Nezjištěno – vyplň token a napiš svému botovi v Telegramu zprávu.');
          break;
        }
        case 'okno': {
          const t = gui.dumpText(state.bot && state.bot.currentWindow);
          const f = log.inspectFile(t);
          console.log(t + (f ? `\n(uloženo do ${f})` : ''));
          break;
        }
        case 'klik': {
          const win = state.bot && state.bot.currentWindow;
          if (!win) { console.log('Žádné okno není otevřené. Otevři ho třeba:  cmd /orders spruce log'); break; }
          const n = parseInt(arg, 10);
          let slot;
          if (Number.isFinite(n) && String(n) === arg.trim()) slot = n;
          else { const t = gui.findInWindow(win, arg) || gui.findInWindow(win, null, arg); if (!t) { console.log(`'${arg}' v okně není – napiš  okno`); break; } slot = t.slot; }
          const p = gui.waitWindowOpen(state.bot, 2500);
          await state.bot.clickWindow(slot, 0, 0);
          await p;
          await sleep(700);
          console.log(gui.dumpText(state.bot.currentWindow));
          break;
        }
        case 'cmd': if (arg && state.bot) state.bot.chat(arg.startsWith('/') ? arg : '/' + arg); break;
        case 'say': if (arg && state.bot) state.bot.chat(arg); break;
        case 'quit': case 'exit': shutdown(0); return;
        default: console.log(`Neznámý příkaz '${c}' – napiš help.`);
      }
    } catch (e) {
      log.err(e.message);
    }
    rl.prompt();
  });

  function shutdown(code) {
    if (state.stopping) return;
    state.stopping = true;
    log.info('Ukončuji bota…');
    try { if (state.bot) state.bot.quit(); } catch (_) { /* pryč */ }
    try { rl.close(); } catch (_) { /* nevadí */ }
    for (const t of timers) clearInterval(t);
    for (const t of connTimers) clearInterval(t);
    if (cycleTimer) clearTimeout(cycleTimer);
    gracefulExit(code, 4000);   // nechat spojení zavřít, teprve pak (pojistka) process.exit
  }
  process.on('SIGINT', () => shutdown(0));
  process.on('SIGTERM', () => shutdown(0));

  // ---- start ----
  console.log('==============================================================');
  console.log(`  SPRUCE BOT  |  ${cfg.server.host}:${cfg.server.port}  |  sleduji: ${(cfg.watch || []).map((w) => w.match).join(', ')}`);
  console.log('  ' + publisher.statusLine());
  if (tradeOn()) {
    const t = cfg.trade;
    console.log(`  Obchodování: ${ts.dryRun ? 'TESTOVACÍ režim (jen píše, co by udělal)' : '!!! OSTRÝ REŽIM – kupuje a prodává doopravdy !!!'}`);
    console.log(`  Pravidla: kup pod $${t.buyBelow} · prodej nad $${t.sellAbove} · ${fmtNum(trade.normalizeUnits(t.buyUnits))} ks/order · max ${t.maxOrders} orderů${t.cancelAfterMinutes > 0 ? ` · zrušit po ${t.cancelAfterMinutes} min bez pohybu` : ''}`);
  } else console.log('  Obchodování: vypnuto (jen sledování cen).');
  console.log('  Napiš  help  pro seznam příkazů.');
  console.log('==============================================================');
  try {
    if (fs.existsSync(CRASH_MARKER)) {
      const m = JSON.parse(fs.readFileSync(CRASH_MARKER, 'utf8'));
      fs.unlinkSync(CRASH_MARKER);
      log.warn('Bot byl restartován po pádu: ' + (m.reason || ''));
      notify.event(cfg, 'crash', `🟢 Bot znovu běží po pádu: ${String(m.reason || '').slice(0, 150)}`).catch(() => {});
    }
  } catch (_) { /* nevadí */ }
  if (!publisher.enabled) log.warn('Publikování na web není nastavené – data zůstanou jen v data/ (spusť: node bot.js --setup).');
  if (cfg.human && cfg.human.activeHours && cfg.human.activeHours.enabled) {
    log.info(`Aktivní hodiny ${cfg.human.activeHours.from}:00–${cfg.human.activeHours.to}:00 (mimo ně bot spí).`);
    timers.push(setInterval(checkActiveHours, 60000));
  }
  if (!inActiveHours() && !flags.once) {
    state.sleeping = true;
    log.info('Teď je mimo aktivní hodiny – připojím se, až začnou.');
  } else {
    connect();
  }
  rl.prompt();
}

// ---------- CLI ----------
if (require.main === module) {
  const args = process.argv.slice(2);
  const flags = { once: args.includes('--once') || args.includes('--dump'), dump: args.includes('--dump') };
  if (args.includes('--setup')) {
    setupWizard().catch((e) => { console.error('CHYBA:', e.message); gracefulExit(1); });
  } else if (args.includes('--test-github')) {
    const cfg = loadConfig();
    new Publisher(cfg).selfTest().then((m) => { console.log(m); gracefulExit(m.startsWith('OK') ? 0 : 1); })
      .catch((e) => { console.error('CHYBA:', e.message); gracefulExit(1); });
  } else {
    const cfg = loadConfig();
    if (!cfg.account.email && cfg.account.auth !== 'offline') {
      console.log('\nNejdřív nastav účet bota:  node bot.js --setup   (nebo do této složky vlož config.local.json z konfigurátoru na webu)\n');
      process.exitCode = 1;
      return;
    }
    main(cfg, flags);
  }
}

module.exports = { loadConfig, deepMerge };
