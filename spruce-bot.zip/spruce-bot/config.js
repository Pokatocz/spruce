// ============================================================
//  NASTAVENÍ BOTA – spruce-bot (sledování cen /orders na DonutSMP)
//  Po úpravě soubor ulož a bota restartuj.
//  Účet, GitHub a Telegram vyplníš pohodlně průvodcem:  node bot.js --setup
//  (uloží se do config.local.json a mají přednost před hodnotami tady).
// ============================================================
'use strict';

module.exports = {
  // ---------- PŘIPOJENÍ ----------
  server: {
    host: 'donutsmp.net',
    port: 25565,
    version: '1.21.4',        // NEMĚNIT: na novějších verzích nefunguje klikání v menu (ověřeno)
  },

  account: {
    auth: 'microsoft',        // 'microsoft' = normální účet (přihlášení kódem, jen poprvé)
    email: '',                // e-mail Microsoft účtu bota (vyplní --setup)
  },

  afterJoinDelayMs: 6000,     // po naskočení do světa počkat, než začne pracovat

  // ---------- CO SLEDOVAT ----------
  // Každý předmět = jeden soubor na webu. Kniha orderů se otevře příkazem `command`.
  watch: [
    {
      match: 'Spruce Log',              // název, jak ho ukazuje menu
      command: '/orders spruce log',    // příkaz, který otevře knihu orderů
      itemId: 'spruce_log',             // minecraft id – počítají se jen tyhle itemy (ne stripped)
      key: 'sprucelog',                 // jméno souborů historie (data/, logs/)
      maxPages: 25,                     // kolik stránek knihy projít (45 orderů na stránku; spruce má ~10 stránek)
      publishPath: 'prices.json',       // soubor v GitHub repu, který čte stránka
      minRealDemand: 25000,             // „reálný vrchol" = nejvyšší cena krytá aspoň tolika kusy
      realPriceFactor: 0.5,             // „reálný order" = cena aspoň 50 % reálného vrcholu (odfiltruje ordery za $1)
    },
  ],

  // Jak z popisku orderu přečíst cenu a doručeno/celkem (ověřeno na DonutSMP).
  orders: {
    priceRegex: '\\$\\s*([0-9][0-9.,]*\\s*[kmb]?)\\s*each',
    deliveredRegex: '([0-9][0-9.,kmb]*)\\s*/\\s*([0-9][0-9.,kmb]*)\\s*[Dd]elivered',
    openTimeoutMs: 8000,      // jak dlouho čekat na otevření menu (na každý pokus)
    pageTimeoutMs: 5000,      // jak dlouho čekat na další stránku
    topOrders: 5,             // „tržní cena" = průměr tolika nejdražších orderů
  },

  // ---------- KOLA (jak často číst) ----------
  cycle: {
    seconds: 240,             // základní interval mezi čteními
    jitterSeconds: 120,       // + náhodně 0–tolik sekund (nepravidelnost = lidštější)
    guiStuckLimit: 2,         // po tolika kolech bez otevřeného menu se bot sám přepojí
  },

  // ---------- WEB (GitHub Pages) ----------
  // Token: github.com → Settings → Developer settings → Fine-grained tokens,
  // jen repo `spruce-data`, oprávnění Contents: Read and write. Test: příkaz  web
  publish: {
    enabled: true,
    owner: '',                // GitHub jméno (vyplní --setup)
    repo: 'spruce-data',
    branch: 'main',
    token: '',                // github_pat_… (vyplní --setup)
    uploadDump: true,         // při prvním čtení (a když nic nenajde) nahrát i výpis GUI do debug/
  },

  // ---------- LIDSKÉ CHOVÁNÍ (anti-detekce, podle ověřeného mc-shop-botu) ----------
  human: {
    activeHours: {
      enabled: false,         // true = mimo hodiny se odpojí a „spí" (stránka ukáže „bot spí")
      from: 9,                // od kolika hodin (místní čas)
      to: 23,                 // do kolika (23 = do 23:00)
    },
    breaks: {
      enabled: true,          // občas si dá pauzu = odpojí se a za chvíli vrátí
      chancePerCycle: 0.03,   // šance na pauzu po kole (0.03 = 3 %)
      minMinutes: 3,
      maxMinutes: 10,
    },
    antiAfk: true,            // občas se rozhlédne / mávne rukou
    antiAfkSeconds: 50,
    actionDelayMs: [700, 1800],   // náhodná pauza mezi kliky [od, do]
  },

  // ---------- SPOJENÍ ----------
  behavior: {
    reconnect: true,
    reconnectDelaySeconds: 45,    // základ; při „already online" se čeká 3–15 min
    chatLog: 'system',            // 'system' = jen hlášky serveru (ne hráčský chat), 'all' = všechno, 'none' = nic
  },

  // ---------- OBCHODOVÁNÍ (volitelné) ----------
  // Nejpohodlněji nastavíš na webu (konfigurátor → config.local.json). Bot obchoduje
  // jen s prvním sledovaným itemem (Spruce Log). Startuje v TESTOVACÍM režimu
  // (dryRun: true) – jen píše, co BY udělal. OSTRÝ režim = dryRun: false (nebo  dry off).
  // POZOR: obchodování ve hře je na vlastní riziko (peníze i pravidla serveru).
  trade: {
    enabled: false,           // true = bot obchoduje podle pravidel níže
    dryRun: true,             // true = TEST (nic nekupuje/neprodává), false = OSTRÝ
    buyBelow: 60,             // vytvoř nákupní order, když je reálná cena POD tolika $/kus (0 = nenakupovat)
    sellAbove: 65,            // prodej naplněný order, když je reálná cena NAD tolika $/kus (0 = neprodávat)
    buyUnits: 2880,           // kolik kusů na jeden order (násobky 2880 = celé stránky; jinak nejde prodat přes emerald)
    maxOrders: 1,             // kolik orderů (i naplněných, ještě neprodaných) smí mít bot najednou
    bidAboveTop: 1,           // cena orderu = reálný vrchol + tolik $ (aby se plnil první), nikdy víc než buyBelow
    priceDecimals: 1,         // na kolik desetinných míst zaokrouhlit cenu orderu
    neverSellAtLoss: true,    // nikdy neprodat pod nákupní cenu (i když je cena nad sellAbove)
    minProfitPct: 0,          // prodat až s tímto ziskem v % nad nákupní cenou (0 = stačí neprodělat)
    cancelAfterMinutes: 0,    // order bez pohybu tolik minut zrušit (0 = nikdy nerušit)
    cooldownMinutes: 0,       // po vytvoření orderu počkat tolik minut na další
    minBalanceReserve: 0,     // vždy nechat na účtu aspoň tolik $ (0 = bez rezervy)
    maxSpendPerHour: 0,       // max útrata za hodinu (0 = bez limitu)
    checkBalance: true,       // před obchodem se zeptat /bal na zůstatek
    openCommand: '/orders',   // hlavní menu trhu (chestka „Your Orders")
    searchName: 'spruce log', // co napsat do vyhledávání při vytváření orderu
    balanceCommand: '/bal',
    balanceRegex: '(?:have|balance|z[ůu]statek|konto|\\$)\\D{0,12}([0-9][0-9\\s.,]*[kKmMbB]?)',

    // ---- KLIKACÍ SEKVENCE (ověřeno na DonutSMP 1.21.4 – neměnit bez důvodu) ----
    // { click: 'text' } klik podle názvu · { clickItem: 'chest' } podle typu itemu
    // { clickIf: 'text' } volitelný klik · { input: '{amount}' } zápis do políčka (cedule/kovadlina/chat)
    // Zástupci: {item} = searchName, {match} = název itemu, {amount} = počet, {price} = cena/kus
    createFlow: [
      { clickItem: 'chest' },                    // chestka „Your Orders"
      { click: 'New Order' },                    // „New Order"
      { click: 'Item' },                         // Item → „Select Item"
      { click: 'Search' },                       // cedule Search
      { input: '{item}' },                       // napsat hledaný název
      { click: '{match}' },                      // klik na nalezený item
      { click: 'Amount' },                       // Amount → cedule
      { input: '{amount}' },                     // počet kusů
      { click: 'Price' },                        // Price → cedule
      { input: '{price}' },                      // cena za kus
      { click: 'Confirm' },                      // potvrdit → order vytvořen
    ],
    sellFlow: [
      { clickItem: 'chest' },                    // chestka „Your Orders"
      { click: '{match}' },                      // naplněný order (bot kliká na konkrétní slot)
      { click: 'Collect' },                      // Collect
      { click: 'Sell', clickItem: 'emerald' },   // emerald „Sell"
      { clickItem: 'lime_stained_glass_pane' },  // zelené sklo = potvrdit prodej
    ],
  },

  // ---------- TELEGRAM UPOZORNĚNÍ (volitelné) ----------
  // @BotFather → /newbot → token; napiš botovi zprávu; v konzoli  tgid  → chatId.
  telegram: {
    enabled: false,
    token: '',
    chatId: '',
    notifyOn: ['crash', 'ban', 'kicks', 'stuck', 'sleep', 'trade'],   // co posílat ('trade' = nákupy/prodeje)
  },
};
