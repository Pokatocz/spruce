@echo off
rem Spousteni na Windows - staci poklepat. Po padu se bot sam restartuje.
cd /d %~dp0
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js neni nainstalovany. Stahni si ho z https://nodejs.org (verze LTS) a spust znovu.
  echo.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Prvni spusteni - instaluji zavislosti...
  call npm install --no-audit --no-fund
)
:loop
node bot.js
if %errorlevel% neq 0 (
  echo.
  echo Bot spadl (kod %errorlevel%) - restartuji za 15 sekund... (zavri okno = konec)
  timeout /t 15 /nobreak >nul
  goto loop
)
echo.
pause
