# spruce-bot – ceny /orders na DonutSMP → web, volitelně obchodování

Samostatný Mineflayer bot: přihlásí se Microsoft účtem, každých pár minut otevře
`/orders spruce log`, projde stránky knihy orderů, přečte cenu za kus a
doručeno/celkem a (pokud je nastavený GitHub) nahraje `prices.json` do repa, ze
kterého ho čte stránka na GitHub Pages (`../web/index.html`).

Volitelně **obchoduje** (sekce `trade` v configu – nejpohodlněji ji vygeneruješ
konfigurátorem na webu): když je reálná cena **pod X**, vytvoří nákupní order
(New Order → Item → Search → Amount → Price → Confirm), a když je reálná cena
**nad Y**, naplněný order vyzvedne a prodá (Collect → emerald Sell → potvrdit).
Umí i zrušit order, který se dlouho nehýbe. Startuje v **testovacím režimu**
(`dryRun: true`) – jen píše, co by udělal; ostrý režim = `dryRun: false` nebo `dry off`.

> Obchodování ve hře je na vlastní riziko (peníze i pravidla serveru). Bot smí
> běžet jen v JEDNÉ instanci na účet („You are already online").

Techniky převzaté z ověřeného mc-shop-botu: vanilla mimikry (`tick_end` +
`player_loaded` – jinak anti-bot kická „Invalid sequence"), lidské chování
(náhodné pauzy, přestávky s odpojením, anti-AFK, volitelné aktivní hodiny),
znovupřipojení s eskalací a delším čekáním po „already online", otevírání menu
s opakováním, samoléčba přepojením když se menu neotvírají, watchdog + restart
přes start skript, Telegram upozornění, klikací sekvence ověřené na DonutSMP 1.21.4.

```bash
npm install
node bot.js --setup        # účet bota, (GitHub), (Telegram) → config.local.json
node bot.js --test-github  # ověří zápis do repa (jen když publikuješ na web)
node bot.js --dump         # jedno čtení + výpis celého menu (poprvé přihlášení kódem)
bash start.sh              # Termux/Linux: trvalý běh   (Windows: start.bat)
npm test                   # testy bez internetu
npm run e2e                # průchod na falešném DonutSMP (přihlášení → 3 stránky → upload)
npm run e2e:trade          # obchodování na falešném DonutSMP (nákup → naplnění → prodej, zrušení)
```

Konzole: `help`, `status`, `cyklus`, `historie`, `web`, `tg`, `tgid`, `okno`,
`klik <název|slot>`, `input <text>`, `seq a > b > input:x`, `cmd </…>`, `say`, `quit`.
Obchodování: `obchod on|off`, `dry on|off`, `ordery`, `bal`, `profit`,
`kup <ks> [cena]`, `prodej [slot]`, `zrus <slot>`.

Nastavení: `config.js` (komentované; `watch` = co sledovat, `cycle` = jak často,
`human` = chování, `publish` = web, `trade` = obchodování). Osobní údaje a tvoje
pravidla jdou do `config.local.json` (průvodce `--setup` nebo konfigurátor na
webu) – ten, `auth-cache/`, `data/` a `logs/` nikdy nedávej na GitHub.

Kompletní klikací návod: `../NAVOD.md` a sekce „Bot ke stažení" na webu.
